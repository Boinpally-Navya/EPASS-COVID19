package com.virtusa.epasscovid19;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Epasscovid19ApplicationTests {

	@Test
	void contextLoads() {
	}

}
